﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class dollarAnim : MonoBehaviour {

	public Animator anim;


	void Start()
	{
		anim.enabled = false;
	}


	public void Dollar()
	{
		anim.enabled = true;
			
	}

}

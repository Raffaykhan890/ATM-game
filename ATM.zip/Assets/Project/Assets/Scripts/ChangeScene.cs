﻿using UnityEngine;
using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;
public class ChangeScene : MonoBehaviour {

  
	public void ChageScene(string sceneName)
	{

		Application.LoadLevel (sceneName);
	}

    public void checkPassword()
    {
        if (PlayerPinScript.PlayerCode == playerCode.Playerpin)
        {
            SceneManager.LoadScene("Scene_4");
        }
        else
        {
           Debug.Log("incorrect");
        }
    }

    

}
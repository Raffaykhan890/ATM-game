﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class displayPassword : MonoBehaviour {

     
    void Update()
    {
        if (PlayerPinScript.Digits < 5)
        {
                if(playerCode.digits==1)
                {
                    GetComponent<TextMesh>().text = "*";
                }
                if (playerCode.digits == 2)
                {
                    GetComponent<TextMesh>().text = "**";
                }
                if (playerCode.digits == 3)
                {
                    GetComponent<TextMesh>().text = "***";
                }
                if (playerCode.digits == 4)
                {
                    GetComponent<TextMesh>().text = "****";
                }          
        }
    }


   

    
}

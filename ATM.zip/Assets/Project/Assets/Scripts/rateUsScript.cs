﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class rateUsScript : MonoBehaviour {

	public void rateUS()
    {
        Application.OpenURL("https://play.google.com/store/apps/details?id=com.google.android.youtube");
    }
}

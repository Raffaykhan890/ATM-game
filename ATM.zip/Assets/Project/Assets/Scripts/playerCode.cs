﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class playerCode : MonoBehaviour {

    public static string Playerpin;
    public static int digits=0;

    void OnMouseUp()
    {
        Playerpin += gameObject.name;
        digits += 1;
    }
}

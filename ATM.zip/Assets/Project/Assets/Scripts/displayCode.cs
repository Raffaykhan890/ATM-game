﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class displayCode : MonoBehaviour {

	
	void Update () {
		if (PlayerPinScript.Digits < 5) {
			GetComponent<TextMesh> ().text = PlayerPinScript.PlayerCode;
		}
	}
}

﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerPinScript : MonoBehaviour {

	public static string PlayerCode;
	public  static int Digits=0;

	void OnMouseUp()
	{
		PlayerCode += gameObject.name;
		Digits += 1;
 	}


}
